var data;               /*variable pour get les donnees*/
var switchPicture=0;    /*variable qui permet a la fonction changePicture de savoir quelle image est presenter*/

getData= function(){                                    /*fonction qui permet de get le fichier .json*/
    fetch("http://localhost:8080/json/output2.json")

    .then(function(response) {
              if (response.ok){
            response.json().then(function(dataResponse){
                data=dataResponse;
                board();
            });
          }

          else{
            console.log("Erreur de reponse")
          }
          
    })

}


board= function(){          /*fonction qui permet de gerer le tableau au complet*/
  var table = document.getElementById("myTable");

 BlocStatic(table);

 var row = table.insertRow();
 var cell = row.insertCell();
 cell.innerHTML='Consumer segment';

 whiteRow(table,row,15);

 dataBloc(table, "consumer.segment");
 row = table.insertRow();
 whiteRow(table,row,16);
 row = table.insertRow();
 cell = row.insertCell();
 cell.innerHTML='Estimated moment';
 whiteRow(table,row,15);

 dataBloc(table, "estimated.usage");


 }


dataBloc=function (table, type){      /*fonction qui permet de gerer le bloc de donnees dans le tableau selon le type (consumer.segment ou estimated.usage)*/

  var size=0;
  if (type == "consumer.segment"){
        size=6;
  }
  else if (type == "estimated.usage") {
        size=10;
  }
    for (var i=0; i<size;i++){
          var row = table.insertRow();
          var cell = row.insertCell();

          cell = row.insertCell(); //whitespace

          if (type == "consumer.segment"){
                cell.innerHTML=data[type][i]["Consumer.Segment"];
          }
          else if (type == "estimated.usage") {
                cell.innerHTML=data[type][i]["Estimated.mobile.data.usage"];
          }

          cell = row.insertCell(); //whitespace

          cell = row.insertCell();
          cell.innerHTML=(data[type][i]["Population"]*100)+"%";
          cell.align="right";


          cell = row.insertCell(); //whitespace

          cell = row.insertCell();
          cell.innerHTML=(data[type][i]["Volume.Baseline.Recontract"]*100)+"%";
          cell.align="right";
          cell = row.insertCell();
          cell.innerHTML=data[type][i]["ARPU.Baseline.Recontract"];
          cell.align="right";

          cell = row.insertCell(); //whitespace

          cell = row.insertCell();
          cell.innerHTML=(data[type][i]["Volume.Scenario.Recontract"]*100)+"%";
          cell.align="right";
          cell = row.insertCell();
          cell.innerHTML=data[type][i]["ARPU.Scenario.Recontract"];
          cell.align="right";

          cell = row.insertCell(); //whitespace

          cell = row.insertCell();
          cell.innerHTML=(data[type][i]["Volume.Baseline.NewCustomers"]*100)+"%";
          cell.align="right";
          cell = row.insertCell();
          cell.innerHTML=data[type][i]["ARPU.Baseline.NewCustomers"];
          cell.align="right";

          cell = row.insertCell(); //whitespace

          cell = row.insertCell();
          cell.innerHTML=(data[type][i]["Volume.Scenario.NewCustomers"]*100)+"%";
          cell.align="right";
          cell = row.insertCell();
          cell.innerHTML=data[type][i]["ARPU.Scenario.NewCustomers"];
          cell.align="right";
    }

}


BlocStatic= function(table){        /*fonction qui permet de gerer le bloc static present au top du tableau pour explique le types de valeurs entrees (exemple: Volume)*/
    var row = table.insertRow();
    whiteRow(table,row,5);
    cell = row.insertCell();
    cell.innerHTML="RECONTRACT";
    cell.className='underline';
    whiteRow(table,row,5);
    cell = row.insertCell();
    cell.innerHTML="NEW CUSTOMER";
    cell.className='underline';
    whiteRow(table,row,4);


    row = table.insertRow();
    whiteRow(table,row,16);


    row = table.insertRow();
    whiteRow(table,row,4);
    for(var i=0;i<2;i++){
        whiteRow(table,row,1);
        cell = row.insertCell();
        cell.innerHTML="BASELINE";
        cell.className='bold';
        whiteRow(table,row,2);
        cell = row.insertCell();
        cell.innerHTML="SCENARIO";
        cell.className='bold';
        whiteRow(table,row,1);
    }



    row = table.insertRow();
    whiteRow(table,row,16);



    row = table.insertRow();
    whiteRow(table,row,3);
    cell = row.insertCell();
    cell.innerHTML="Population";
    cell.className='italic';
    for (var i=0;i<4;i++){
        whiteRow(table,row,1);
        cell = row.insertCell();
        cell.innerHTML="Volume";
        cell.className='italic';
        cell = row.insertCell();
        cell.innerHTML="ARPU";
        cell.className='italic';
    }


    row = table.insertRow();
    whiteRow(table,row,16);

}


whiteRow=function(table,row,size){ /*fonction qui permet de faire un espace blanc selon la taille entree en parametre*/


    for (var i=0;i<size;i++){
        var cell = row.insertCell();

    }
}


document.addEventListener('DOMContentLoaded', function(){
    getData();

}, false);



changePicture=function(){       /*fonction qui permet de changer l image present en output si une valeur est changer dans les inputs*/
    if (switchPicture===0){
        document.getElementById("fig4").style.display="block";
        document.getElementById("myTable").style.display="none";
        switchPicture=1;
    }
    else if (switchPicture===1){
        document.getElementById("fig4").style.display="none";
        document.getElementById("myTable").style.display="block";
        switchPicture=0;
    }
}


buttonBold=function(show){          /*fonction qui permet de mettre les boutons inputs ou outputs lorsqu ils sont utiliser*/
    if (show==="output"){
        document.getElementById("inputsButton").style.fontWeight = "normal";
        document.getElementById("outputButton").style.fontWeight = "bold";
    }
    else if (show==="inputs"){
        document.getElementById("inputsButton").style.fontWeight = "bold";
        document.getElementById("outputButton").style.fontWeight = "normal";


    }
}
