var nbScenario=0;
var chartColors = ["#FF5D4B", "#FF7002", "#FCE754", "#98D447", "#61A2F6", "#D092D9"];
var scenarios = ["Scenario Ref", "Scenario 1", "Scenario 2", "Scenario 3", "Scenario 4", "Scenario 5"];
var scenariosIds = ["scenarioPrincipal", "scenario1", "scenario2", "scenario3", "scenario4", "scenario5"];

add = function (show, actuel,reference) {
    if(document.getElementById(actuel).getElementsByClassName("benef")[0].textContent!=''){
        document.getElementById(actuel).getElementsByClassName("boutonPlus")[0].style.display = "none";
        document.getElementById(show).style.display = "table-row";
        if (reference==0){
            document.getElementById(actuel).getElementsByClassName("boutonMoins")[0].style.display = "none";
        }
        nbScenario++;

    }
}

remove = function (hide, back,reference) {
    document.getElementById(hide).getElementsByTagName("input")[0].value='';
    document.getElementById(hide).getElementsByTagName("input")[1].value='';
    document.getElementById(hide).getElementsByTagName("input")[2].value='';
    document.getElementById(hide).getElementsByClassName("benef")[0].textContent='';
    nbScenario--;

    document.getElementById(hide).style.display = "none";
    document.getElementById(back).getElementsByClassName("boutonPlus")[0].style.display = "table-cell";
    if (reference==0){
        document.getElementById(back).getElementsByClassName("boutonMoins")[0].style.display = "table-cell";
    }

    row=document.getElementById(back).getElementsByTagName("input")[0].parentNode.parentNode;
    updateGraph(row.id);

}

calculerBenefice = function (modifiedInput) {
    row = modifiedInput.parentNode.parentNode;
    oldBenef = row.getElementsByClassName("benef")[0].textContent;
    if (verifierValiditeInputs(row)) {
        var prixAchat = row.getElementsByTagName("input")[0].value;
        var prixVente = row.getElementsByTagName("input")[2].value;

        row.getElementsByClassName("benef")[0].textContent = (((prixVente - prixAchat) / prixVente) * 100).toString().substring(0, 5);
    }
    newBenef = row.getElementsByClassName("benef")[0].textContent;
    if (oldBenef !== newBenef)
        updateGraph(row.id);

}

verifierValiditeInputs = function (row) {
    var inputs = row.getElementsByTagName("input");

    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].value === "")
            return false;
    }
    return true;
}

updateGraph = function (rowId) {
    var nRows = scenariosIds.indexOf(rowId);
    var benefices = document.getElementsByClassName("benef");

    if (nRows === -1)
        return;

    google.charts.load("current", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(function () {



        var arr = new Array(nRows + 2);
        arr[0] = ["Element", "Benefice", { role: "style" }];


        for (var i = 1; i < nbScenario+2; i++) {
            arr[i] = [scenarios[i - 1], parseInt(benefices[i - 1].textContent), chartColors[i - 1]];
        }

        var data = google.visualization.arrayToDataTable(arr);

        var view = new google.visualization.DataView(data);
        view.setColumns([0, 1,
            {
                calc: "stringify",
                type: "string",
                role: "annotation"
            },
            2]);

        var options = {
            title: "Bénéfice",
            width: 600,
            height: 400,
            bar: { groupWidth: "50%" },
            legend: { position: "none" },
        };
        var chart = new google.visualization.BarChart(document.getElementById("graph"));
        chart.draw(view, options);

    });
}

